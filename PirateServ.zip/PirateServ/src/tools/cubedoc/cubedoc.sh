#!/bin/sh
python cubedoc.py ./templates ../../../docs/ ../../
