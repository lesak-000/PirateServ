This is reduced version of MySQL Connector/C
Some functions and features were deleted to reduce size. This version supports only utf-8 and latin1 encodings.
See include/my_charsets.h