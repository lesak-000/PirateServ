irc.cpp, irc.h imported from Red Eclipse
Red Eclipse is based on Cube Engine 2, both of which are covered under the ZLIB
    license, you may use the source code so long as you obey this license.

    Red Eclipse, Copyright (C) 2010 Quinton Reeves, Lee Salzman 
    Cube Engine 2, Copyright (C) 2001-2010 Wouter van Oortmerssen, Lee Salzman,
        Mike Dysart, Robert Pointon, and Quinton Reeves
    http://www.opensource.org/licenses/zlib-license.php 
